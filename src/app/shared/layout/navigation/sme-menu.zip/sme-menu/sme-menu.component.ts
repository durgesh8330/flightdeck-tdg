import { MyWorkgroupTaskComponent } from './../../../../features/task/my-workgroup-task/my-workgroup-task.component';
import { MyTaskComponent } from './../../../../features/task/my-task/my-task.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, Type, EventEmitter, Output } from '@angular/core';
import {SearchTaskComponent} from '@app/features/task/search-task/search-task.component';
import {SearchResultComponent} from '@app/features/task/search-result/search-result.component';
import {AnalyticsComponent} from '@app/features/dashboard/analytics/analytics.component';
import {ProfileInfoComponent} from '@app/features/profile/profile-info/profile-info.component';
import { MatSnackBar } from '@angular/material';
import { TaskService } from '@app/features/task/task.service';

import {TabService} from '@app/core/tab/tab-service';
import {LayoutService} from '@app/core/services';
import {Tab} from '@app/core/tab/tab.model';
import { environment } from '@env/environment';

@Component({
  selector: 'sme-menu',
  templateUrl: './sme-menu.component.html',
  styleUrls: ['./sme-menu.component.scss']
})
export class SmeMenuComponent implements OnInit {
  public permissionList = [];
  public leftMenuData = {leftMenu: []};
  public pageLayout: any;
  public smeSearch: any = {};
  public searchReq:any = {};
  public showSearchMenu: boolean = false;
  @Output() showMainMenu = new EventEmitter();
  swithcToMainMenu(){
    this.showMainMenu.emit();
  }
  
  constructor(
    private taskService: TaskService,
    private tabService: TabService,
    private layoutService: LayoutService, private httpClient: HttpClient, private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    let themeLink = JSON.parse(localStorage.getItem('themeLink'));
    if (themeLink && themeLink.leftMenu) {
      this.permissionList = themeLink.leftMenu.split(';');
      if (!this.permissionList) {
        this.permissionList = [];
      }
    }
    this.getTemplateData();
  }
  templateObj: any = {};
  searchTypes: any = [];
  searchType: string = 'Request';

  getTemplateData() {
    this.httpClient.get(environment.apiUrl+'/PageLayoutTemplate/Get/SME Search').toPromise().then((response: any) =>{
      this.pageLayout = response.pageLayoutTemplate;
      if(this.pageLayout && this.pageLayout.length > 0){
         this.pageLayout.forEach((section: any)=>{
          const searchType = section.sectionHeader.split(' ')[0];
          this.templateObj[searchType] = section.fieldsList;
          if(searchType != 'Buttons')
            this.searchTypes.push(searchType);
         });
      }
    }).catch(errorObj => console.error(errorObj));
      // const userObj = JSON.parse(localStorage.getItem('fd_user'));
      // if(userObj && userObj.authorizations && userObj.authorizations.length > 0){
      //   this.checkAccessLevels(userObj.authorizations);
      // }else{
      //   this.leftMenuData.leftMenu = [];
      // }
  }
  
  checkAccessLevels(authorizations: any){
    const usersLeftPermissions = authorizations.filter((authElement: any) => authElement.startsWith('LeftMenu'));
    for(let i=0; i<this.leftMenuData.leftMenu.length; i++){
        const menuItem: any = this.leftMenuData.leftMenu[i];  
        if(menuItem && ((menuItem['headerLabel'] == 'Dashboard' && usersLeftPermissions.indexOf('LeftMenu_dashboard') == -1) || 
           (menuItem['headerLabel'] == 'Task' && usersLeftPermissions.indexOf('LeftMenu_advancedTaskSearch') == -1) || 
           (menuItem['headerLabel'] == 'Create' && usersLeftPermissions.indexOf('LeftMenu_ASRITask_Create') == -1) || 
           (menuItem['headerLabel'] == 'My Tasks' && usersLeftPermissions.indexOf('LeftMenu_myTasks') == -1) || 
           (menuItem['headerLabel'] == 'My Workgroup Tasks' && usersLeftPermissions.indexOf('LeftMenu_myGroupsTasks') == -1))){
          this.leftMenuData.leftMenu.splice(i, 1);
          i--;
        }
    }
  }
  
  openTab(componentStr, title, url) {
    console.log(componentStr, title, url);
    if (componentStr) {
      console.log(url)
      let tab = new Tab(this.getComponentType(componentStr), title, url, {});
      this.tabService.openTab(tab);
    }
    // if(this.openedTab.findIndex(x => x === componentStr) > -1){
    //   let tab = new Tab(this.getComponentType(componentStr), title, url, {});
    //   this.tabService.openTab(tab);
    //   this.openedTab.push(componentStr);
    // }
  }

  getComponentType(componentStr: string): Type<any> {
    let componentType: Type<any>;
    console.log(componentStr);
    switch (componentStr) {
      case 'SearchTaskComponent':
        componentType = SearchTaskComponent;
        break;
      case 'ProfileInfoComponent':
        componentType = ProfileInfoComponent;
        break;
      case 'AnalyticsComponent':
        componentType = AnalyticsComponent;
        break;
      case 'MyTaskComponent':
        componentType = MyTaskComponent;
        break;
      case 'MyWorkgroupTaskComponent':
        componentType = MyWorkgroupTaskComponent;
        break;
    }
    return componentType;
  }
  
  toggleOnHover(state) {
    this.layoutService.onMouseToggleMenu(state);
  }

  onClickLink(state, e) {}

  searchTask(searchReq){
    let reqData:any={"sourceSystemList":["LMOS"],"workgroupList":null,"taskTypeList":null,"TTN":searchReq.TTN,"TN":searchReq.TN, "EC": searchReq.EC}

    this.taskService.searchTask(reqData).toPromise().then((result: any) => {
      
      if (result && result.taskResults && result.taskResults.length > 0) {

        //this.dataStorageService.setData(result.taskResults);
        //remove below line when backend is ready
        //result.pagination = {pageNumber: 1, pageSize: 100, totalRecords: result.taskResults.length};
        //this.dataStorageService.setPagination(result.pagination);
        //this.dataStorageService.setSearchCriteria(this.request);
        // this.showResultsTemp = true;
        let tab = new Tab(SearchResultComponent, 'Search Result', 'searchTask', {});
        this.tabService.openTab(tab);
      } else {
        this.snackBar.open("No Data Found for the provided criteria, Please try searching with valid data.", "Okay", {
          duration: 15000,
        });
      }
    }, (error: any) => {
      console.log(error);
      //this.loader = false;
      this.snackBar.open("Error Searching for Task", "Okay", {
        duration: 15000,
      });
    });
  }
}
